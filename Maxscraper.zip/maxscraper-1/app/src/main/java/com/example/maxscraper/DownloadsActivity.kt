package com.example.maxscraper

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit

class DownloadsActivity : AppCompatActivity() {

    private lateinit var btnActive: Button
    private lateinit var btnCompleted: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)

        // Toolbar with back arrow
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.title_downloads)

        btnActive = findViewById(R.id.btnActive)
        btnCompleted = findViewById(R.id.btnCompleted)

        btnActive.setOnClickListener { showActive() }
        btnCompleted.setOnClickListener { showCompleted() }

        // First load: show Active
        if (savedInstanceState == null) {
            showActive()
        } else {
            // restore button highlight
            val tag = supportFragmentManager.findFragmentById(R.id.content)?.tag
            updateButtons(tag == TAG_ACTIVE)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun showActive() {
        supportFragmentManager.commit {
            replace(R.id.content, ActiveFragment(), TAG_ACTIVE)
        }
        updateButtons(true)
    }

    private fun showCompleted() {
        supportFragmentManager.commit {
            replace(R.id.content, CompletedFragment(), TAG_COMPLETED)
        }
        updateButtons(false)
    }

    private fun updateButtons(activeSelected: Boolean) {
        // Simple visual state; adjust to your theme as needed
        btnActive.isEnabled = !activeSelected
        btnCompleted.isEnabled = activeSelected
    }

    companion object {
        private const val TAG_ACTIVE = "active"
        private const val TAG_COMPLETED = "completed"
    }
}
