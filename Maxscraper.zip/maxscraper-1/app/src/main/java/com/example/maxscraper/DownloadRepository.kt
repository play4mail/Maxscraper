package com.example.maxscraper

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment

object DownloadRepository {

    fun startDownload(ctx: Context, url: String, fileName: String, referer: String?) : Long {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(fileName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)

        if (!referer.isNullOrBlank()) req.addRequestHeader("Referer", referer)
        req.addRequestHeader("User-Agent", "Mozilla/5.0")

        val id = dm.enqueue(req)
        DownloadTracker.add(ctx, id)
        return id
    }

    fun cancel(ctx: Context, id: Long) {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        try {
            dm.remove(id) // removes just this download (others remain)
            DownloadTracker.remove(ctx, id)
        } catch (_: Throwable) { /* ignore */ }
    }
}
