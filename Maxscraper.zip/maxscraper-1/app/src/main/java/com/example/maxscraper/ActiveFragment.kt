package com.example.maxscraper

import android.app.DownloadManager
import android.content.*
import android.database.Cursor
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.max
import kotlin.math.roundToLong

/**
 * Active downloads with metadata (HLS + DM).
 * Reads HlsStatusStore on resume to seed a row immediately.
 */
class ActiveFragment : Fragment() {

    private lateinit var recycler: RecyclerView
    private lateinit var empty: TextView
    private val adapter = Rows()
    private val rows = LinkedHashMap<String, Row>()
    private val ui = Handler(Looper.getMainLooper())

    // DM polling
    private val dmPrev = HashMap<Long, Pair<Long, Long>>() // id -> (bytes, t_ms)
    private val dmPoll = object : Runnable {
        override fun run() {
            try { pollDownloadManager() } finally { ui.postDelayed(this, 1000) }
        }
    }

    // HLS receivers
    private val hlsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            when (intent.action) {
                HlsToMp4Service.ACTION_PROGRESS -> {
                    val jobId = intent.getLongExtra(HlsToMp4Service.EXTRA_JOB_ID, -1L)
                    val title = intent.getStringExtra(HlsToMp4Service.EXTRA_TITLE) ?: "Converting"
                    val percent = intent.getIntExtra(HlsToMp4Service.EXTRA_PERCENT, 1).coerceIn(1, 100)
                    val elapsedMs = intent.getLongExtra(HlsToMp4Service.EXTRA_ELAPSED_MS, 0L)
                    val totalMs = intent.getLongExtra(HlsToMp4Service.EXTRA_DURATION_MS, 0L)
                    val bytes = intent.getLongExtra(HlsToMp4Service.EXTRA_BYTES, 0L)
                    if (jobId > 0) {
                        val key = "hls-$jobId"
                        val r = rows[key] ?: Row(key, title, isHls = true, hlsJobId = jobId)
                        r.title = title
                        r.percent = percent
                        r.bytesSoFar = bytes
                        r.totalBytes = 0L
                        r.durationMs = totalMs
                        r.etaMs = if (totalMs > 0 && elapsedMs in 1..(totalMs - 1)) (totalMs - elapsedMs) else -1L
                        rows[key] = r
                        refreshList()
                    }
                }
                HlsToMp4Service.ACTION_DONE -> {
                    val jobId = intent.getLongExtra(HlsToMp4Service.EXTRA_JOB_ID, -1L)
                    if (jobId > 0) {
                        rows.remove("hls-$jobId")
                        refreshList()
                    }
                }
            }
        }
    }

    override fun onCreateView(inflater: android.view.LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val root = FrameLayout(requireContext())

        recycler = RecyclerView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@ActiveFragment.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }
        empty = TextView(requireContext()).apply {
            text = "No active downloads"
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        root.addView(recycler)
        root.addView(empty)
        return root
    }

    override fun onResume() {
        super.onResume()

        // Seed from HlsStatusStore immediately (shows row even if first stat hasn't arrived)
        HlsStatusStore.snapshot()?.let { s ->
            if (s.percent in 1..99) {
                val key = "hls-${s.jobId}"
                rows[key] = Row(
                    key = key,
                    title = s.title,
                    percent = s.percent,
                    isHls = true,
                    hlsJobId = s.jobId,
                    bytesSoFar = s.bytes,
                    totalBytes = 0L,
                    durationMs = s.totalMs,
                    etaMs = if (s.totalMs > 0 && s.elapsedMs in 1..(s.totalMs - 1)) (s.totalMs - s.elapsedMs) else -1L
                )
                refreshList()
            }
        }

        val f = IntentFilter().apply {
            addAction(HlsToMp4Service.ACTION_PROGRESS)
            addAction(HlsToMp4Service.ACTION_DONE)
        }
        ContextCompat.registerReceiver(requireContext(), hlsReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        LocalBroadcastManager.getInstance(requireContext()).registerReceiver(hlsReceiver, f)

        ui.post(dmPoll)
        pollDownloadManager()
    }

    override fun onPause() {
        super.onPause()
        try { requireContext().unregisterReceiver(hlsReceiver) } catch (_: Throwable) {}
        try { LocalBroadcastManager.getInstance(requireContext()).unregisterReceiver(hlsReceiver) } catch (_: Throwable) {}
        ui.removeCallbacks(dmPoll)
    }

    // ---- DM polling ----
    private fun pollDownloadManager() {
        val ctx = context ?: return
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val ids = try { DownloadTracker.allIds(ctx) } catch (_: Throwable) { longArrayOf() }
        val keep = HashSet<String>()
        val now = System.currentTimeMillis()

        ids.forEach { id ->
            var c: Cursor? = null
            try {
                c = dm.query(DownloadManager.Query().setFilterById(id))
                if (c != null && c.moveToFirst()) {
                    val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Download"
                    val soFar = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)).coerceAtLeast(0L)
                    val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)).coerceAtLeast(0L)

                    val key = "dm-$id"
                    when (status) {
                        DownloadManager.STATUS_PENDING,
                        DownloadManager.STATUS_RUNNING,
                        DownloadManager.STATUS_PAUSED -> {
                            val percent = if (total > 0) ((soFar * 100.0) / total).toInt().coerceIn(1, 99) else 1
                            val r = rows[key] ?: Row(key, title, isHls = false, dmId = id)
                            r.title = title
                            r.percent = percent
                            r.bytesSoFar = soFar
                            r.totalBytes = if (total > 0) total else -1
                            r.durationMs = -1L
                            val prev = dmPrev[id]
                            val eta = if (total > 0 && prev != null) {
                                val dBytes = max(1L, soFar - prev.first)
                                val dMs = max(1L, now - prev.second)
                                val bytesPerSec = (dBytes * 1000.0 / dMs).coerceAtLeast(1.0)
                                val remaining = total - soFar
                                (remaining / bytesPerSec).roundToLong() * 1000L
                            } else -1L
                            r.etaMs = eta

                            rows[key] = r
                            keep += key
                            dmPrev[id] = soFar to now
                        }
                        DownloadManager.STATUS_SUCCESSFUL,
                        DownloadManager.STATUS_FAILED -> { /* drop; receiver/completed handles */ }
                    }
                }
            } catch (_: Throwable) {
            } finally { try { c?.close() } catch (_: Throwable) {} }
        }

        rows.keys.filter { it.startsWith("dm-") && it !in keep }.forEach { rows.remove(it) }
        refreshList()
    }

    private fun refreshList() {
        val list = rows.values.toList()
        adapter.data = list
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    data class Row(
        val key: String,
        var title: String,
        var percent: Int = 1,
        val isHls: Boolean,
        val hlsJobId: Long? = null,
        val dmId: Long? = null,
        var bytesSoFar: Long = 0L,
        var totalBytes: Long = -1L,
        var durationMs: Long = -1L,
        var etaMs: Long = -1L
    )

    inner class Rows : RecyclerView.Adapter<VH>() {
        var data: List<Row> = emptyList()
            set(value) { field = value; notifyDataSetChanged() }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 16, 24, 16)
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val title = TextView(parent.context).apply { textSize = 16f; setTextColor(Color.WHITE) }
            val subTop = LinearLayout(parent.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val bar = ProgressBar(parent.context, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val pct = TextView(parent.context).apply { setTextColor(Color.LTGRAY); setPadding(12, 0, 12, 0) }
            val btn = Button(parent.context).apply { text = "Cancel"; setAllCaps(false) }
            subTop.addView(bar); subTop.addView(pct); subTop.addView(btn)
            val meta = TextView(parent.context).apply { setTextColor(0xFFB0BEC5.toInt()); textSize = 13f; setPadding(0, 6, 0, 0) }

            row.addView(title); row.addView(subTop); row.addView(meta)
            return VH(row, title, bar, pct, btn, meta)
        }

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(data[position])
        override fun getItemCount(): Int = data.size
    }

    inner class VH(
        root: View,
        private val titleView: TextView,
        private val bar: ProgressBar,
        private val pctView: TextView,
        private val btnCancel: Button,
        private val metaView: TextView
    ) : RecyclerView.ViewHolder(root) {

        fun bind(r: Row) {
            titleView.text = r.title + if (r.isHls) " (HLS)" else ""
            bar.isIndeterminate = false
            bar.progress = r.percent.coerceIn(0, 100)
            pctView.text = "${r.percent.coerceIn(0,100)}%"

            val sizeStr = if (r.isHls) {
                if (r.bytesSoFar > 0) humanBytes(r.bytesSoFar) else "—"
            } else {
                if (r.totalBytes > 0) "${humanBytes(r.bytesSoFar)} / ${humanBytes(r.totalBytes)}" else humanBytes(r.bytesSoFar)
            }
            val durStr = if (r.durationMs > 0) humanTime(r.durationMs) else "—"
            val etaStr = if (r.etaMs > 0) humanTime(r.etaMs) else if (r.percent in 1..99) "estimating…" else "—"
            metaView.text = "Size: $sizeStr   •   Duration: $durStr   •   Time left: $etaStr"

            btnCancel.setOnClickListener {
                val ctx = it.context
                if (r.isHls) {
                    try { ctx.startService(Intent(ctx, HlsToMp4Service::class.java).setAction("cancel")) } catch (_: Throwable) {}
                } else {
                    r.dmId?.let { id -> DownloadRepository.cancel(ctx, id) }
                }
            }
        }

        private fun humanBytes(b: Long): String {
            val kb = 1024.0; val mb = kb * 1024; val gb = mb * 1024
            return when {
                b >= gb -> String.format("%.2f GB", b / gb)
                b >= mb -> String.format("%.2f MB", b / mb)
                b >= kb -> String.format("%.1f KB", b / kb)
                else -> "$b B"
            }
        }
        private fun humanTime(ms: Long): String {
            val total = (ms / 1000).toInt()
            val s = total % 60; val m = (total / 60) % 60; val h = total / 3600
            return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
        }
    }
}
