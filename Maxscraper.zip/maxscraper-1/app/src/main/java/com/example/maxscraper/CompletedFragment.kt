package com.example.maxscraper

import android.app.DownloadManager
import android.content.*
import android.database.Cursor
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.DecimalFormat
import java.util.concurrent.ConcurrentHashMap

/**
 * Completed shows only real files (exists && size > 0).
 * "Delete" removes from the app list, but DOES NOT delete Gallery/MediaStore items.
 */
class CompletedFragment : Fragment() {

    private lateinit var recycler: RecyclerView
    private lateinit var empty: TextView
    private val adapter = Rows()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refresh() }
    }

    override fun onCreateView(
        inflater: android.view.LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val root = FrameLayout(requireContext())

        recycler = RecyclerView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@CompletedFragment.adapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }
        empty = TextView(requireContext()).apply {
            text = "No completed downloads"
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        ContextCompat.registerReceiver(
            requireContext(),
            receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        root.addView(recycler)
        root.addView(empty)
        return root
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { super.onPause(); try { requireContext().unregisterReceiver(receiver) } catch (_: Throwable) {} }

    private fun refresh() {
        val ctx = requireContext()
        val rows = linkedMapOf<String, Row>() // key by uri string

        // DownloadManager successful items (from our tracked IDs only)
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val ids = DownloadTracker.allIds(ctx)
        if (ids.isNotEmpty()) {
            var c: Cursor? = null
            try {
                c = dm.query(DownloadManager.Query().setFilterById(*ids))
                if (c != null) while (c.moveToNext()) {
                    val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    if (status != DownloadManager.STATUS_SUCCESSFUL) continue
                    val title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Download"
                    val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) ?: continue
                    val uri = Uri.parse(local)
                    val size = realSize(ctx, uri)
                    if (size > 0L) rows[uri.toString()] = Row(title, uri, size, dmId = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)))
                }
            } finally { try { c?.close() } catch (_: Throwable) {} }
        }

        // HLS conversions written by CompletedStore
        CompletedStore.all(ctx).forEach { item ->
            val size = if (item.size > 0) item.size else realSize(ctx, item.uri)
            if (size > 0L) rows[item.uri.toString()] = Row(item.title, item.uri, size, dmId = null)
        }

        val list = rows.values.toMutableList()
        adapter.data = list
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    data class Row(val title: String, val uri: Uri, val sizeBytes: Long, val dmId: Long?)

    inner class Rows : RecyclerView.Adapter<VH>() {
        var data: List<Row> = emptyList()
            set(value) { field = value; notifyDataSetChanged() }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = android.view.LayoutInflater.from(parent.context)
                .inflate(R.layout.item_completed_download, parent, false)
            return VH(v, this)
        }
        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(data[position])
        override fun getItemCount(): Int = data.size
    }

    class VH(itemView: View, private val adapter: Rows) : RecyclerView.ViewHolder(itemView) {
        private val thumb: ImageView = itemView.findViewById(R.id.thumb)
        private val title: TextView = itemView.findViewById(R.id.title)
        private val subtitle: TextView = itemView.findViewById(R.id.subtitle)
        private val btnDelete: Button = itemView.findViewById(R.id.btnDelete)

        fun bind(r: Row) {
            title.text = r.title
            subtitle.text = formatSize(r.sizeBytes)
            loadThumbInto(thumb, r.uri)

            itemView.setOnClickListener {
                val i = Intent(itemView.context, PlayerActivity::class.java)
                    .setData(r.uri)
                    .putExtra(PlayerActivity.EXTRA_TITLE, r.title)
                itemView.context.startActivity(i)
            }

            btnDelete.setOnClickListener {
                val ctx = itemView.context

                // If tracked via DownloadManager, ONLY untrack it (do NOT dm.remove which deletes file)
                try {
                    val id = r.dmId
                    if (id != null) {
                        DownloadTracker.remove(ctx, id) // untrack in app
                        // DO NOT call DownloadManager.remove(id) — that deletes the file from public storage
                    }
                } catch (_: Throwable) {}

                // Remove from CompletedStore (for HLS records)
                try { CompletedStore.removeByUri(ctx, r.uri) } catch (_: Throwable) {}

                // Delete actual file ONLY if it's app-private or file:// under our dir.
                // Never delete MediaStore (Gallery) content.
                try {
                    if (r.uri.scheme == "file") {
                        val f = File(r.uri.path ?: "")
                        // delete only if in our private area
                        val base = ctx.getExternalFilesDir(null)?.absolutePath ?: ""
                        if (f.absolutePath.startsWith(base)) f.delete()
                    } else if (r.uri.scheme == "content") {
                        // Skip MediaStore provider (keep file in gallery)
                        val auth = r.uri.authority ?: ""
                        if (!auth.contains("com.android.providers.media")) {
                            // If it's our SAF doc (e.g., app private), allow delete
                            DocumentFile.fromSingleUri(ctx, r.uri)?.let { doc ->
                                val parent = ctx.getExternalFilesDir(null)?.absolutePath ?: ""
                                val pth = doc.uri.path ?: ""
                                if (pth.contains(parent)) doc.delete()
                            }
                        }
                    }
                } catch (_: Throwable) {}

                // Update UI
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    val list = adapter.data.toMutableList()
                    list.removeAt(pos)
                    adapter.data = list
                }
            }
        }

        private fun formatSize(bytes: Long): String {
            val kb = 1024.0; val mb = kb * 1024; val gb = mb * 1024
            val df = DecimalFormat("#,##0.00")
            return when {
                bytes >= gb -> df.format(bytes / gb) + " GB"
                bytes >= mb -> df.format(bytes / mb) + " MB"
                bytes >= kb -> df.format(bytes / kb) + " KB"
                else -> "$bytes B"
            }
        }

        private fun loadThumbInto(view: ImageView, uri: Uri) {
            val key = uri.toString()
            ThumbCache[key]?.let { view.setImageBitmap(it); return }
            view.setImageResource(android.R.drawable.ic_media_play)
            Thread {
                val bmp = frameFromUri(view.context, uri)
                (view.context as? android.app.Activity)?.runOnUiThread {
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        if (adapter.data.getOrNull(adapterPosition)?.uri?.toString() == key && bmp != null) {
                            ThumbCache[key] = bmp
                            view.setImageBitmap(bmp)
                        }
                    }
                }
            }.start()
        }

        private fun frameFromUri(ctx: Context, uri: Uri): Bitmap? {
            return try {
                val mmr = MediaMetadataRetriever()
                if (uri.scheme == "content") {
                    val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
                    pfd.use { mmr.setDataSource(it.fileDescriptor) }
                } else {
                    mmr.setDataSource(ctx, uri)
                }
                val bmp = mmr.getFrameAtTime(0)
                mmr.release()
                bmp
            } catch (_: Throwable) { null }
        }

        companion object { private val ThumbCache = ConcurrentHashMap<String, Bitmap?>() }
    }

    private fun realSize(ctx: Context, uri: Uri): Long {
        return try {
            when (uri.scheme) {
                "content" -> {
                    val c = ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)
                    c?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
                }
                "file" -> File(uri.path ?: "").length()
                else -> 0L
            }
        } catch (_: Throwable) { 0L }
    }
}
