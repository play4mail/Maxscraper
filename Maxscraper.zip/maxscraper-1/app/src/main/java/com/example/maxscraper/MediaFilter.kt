package com.example.maxscraper

import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.min

/**
 * Shared media filtering helpers.
 * - Drops ad/tracker hosts.
 * - MP4 filter now accepts progressive MP4 URLs *without* ".mp4" extension
 *   (e.g., "videoplayback?..."), using URL hints or HEAD Content-Type.
 * - Keeps size threshold (now 0.5 MB) to avoid junk.
 * - HLS variants: allow ANY resolution height present, not ads.
 */
object MediaFilter {

    // Basic ad/tracker fragments
    private val BAD_HOST_PARTS = listOf(
        "doubleclick", "googlesyndication", "adservice", "adnxs", "moatads",
        "taboola", "outbrain", "trustx", "advertising",
        "scorecardresearch", "pubmatic", "criteo", "mgid",
        "zedo", "rubiconproject", "openx", "imasdk", "adsterra", "exoclick"
    )

    // Quality hints (used to sort MP4s if present, but NOT required anymore)
    private val QUAL_RE = Regex("""(?i)\b(1080|720|480|360|240)\s*p?\b""")
    private val BITRATE_RE = Regex("""(?i)\b([5-9]\d{2}|[1-9]\d{3}|10000)k\b""") // 500k..10,000k

    // MP4 URL detection (extension or query hints)
    private val MP4_EXT_RE = Regex("""(?i)\.mp4(\b|[?#])""")
    private val MP4_URL_HINT_RE = Regex("""(?i)(mime=video%2Fmp4|mime=video/mp4|type=video/mp4|format=mp4|videoplayback)""")

    /** True if URL likely belongs to an ad/tracker domain or ad path. */
    fun isLikelyAd(url: String): Boolean {
        val u = url.lowercase(Locale.US)
        if (!u.startsWith("http")) return true
        if ("/ad/" in u || "/ads/" in u) return true
        return BAD_HOST_PARTS.any { it in u }
    }

    /** Extracts height (H) from WxH (e.g., "1920x1080") -> 1080. Returns null if not parseable. */
    fun heightFromResolution(resolution: String?): Int? {
        val r = resolution?.lowercase(Locale.US) ?: return null
        val h = r.substringAfter('x', missingDelimiterValue = "").toIntOrNull()
        return h?.takeIf { it > 0 }
    }

    /** Allow HLS variant if it has ANY valid resolution height and is not obviously an ad. */
    fun allowHlsVariant(resolution: String?, url: String): Boolean {
        if (isLikelyAd(url)) return false
        return heightFromResolution(resolution) != null
    }

    /**
     * MP4-only filter.
     * - Accept if URL *looks like* MP4 (".mp4" OR query hints OR HEAD Content-Type=*mp4*).
     * - Drop tiny (< 0.5MB) and ads.
     * - Sort by quality tokens / bitrate, then by size descending (when available).
     */
    fun filterMp4(raw: List<String>): List<String> {
        if (raw.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        val sizeCache = HashMap<String, Long>()

        raw.forEach { url ->
            val u = url.trim()
            if (isLikelyAd(u)) return@forEach
            if (!isProbableMp4(u)) return@forEach

            val len = headContentLength(u).also { sizeCache[u] = it }
            // Drop obviously tiny files (junk/tracking); unknown (-1) passes
            if (len in 1 until (512L * 1024)) return@forEach

            out += u
        }

        val list = out.toList()
        return list.sortedWith(
            compareByDescending<String> { qualityScore(it) }
                .thenByDescending { (sizeCache[it] ?: -1L).coerceAtLeast(-1L) }
        )
    }

    // ---------- Internals ----------

    /** Heuristic: is this URL likely an MP4? */
    private fun isProbableMp4(url: String): Boolean {
        if (MP4_EXT_RE.containsMatchIn(url)) return true
        if (MP4_URL_HINT_RE.containsMatchIn(url)) return true
        // As a fallback, peek HEAD Content-Type (off main thread)
        val ct = headContentType(url) ?: return false
        return ct.contains("mp4", ignoreCase = true)
    }

    /** Rough URL-based quality scoring used for sorting MP4s (higher is better). */
    private fun qualityScore(url: String): Int {
        val q = QUAL_RE.find(url)?.groupValues?.getOrNull(1)?.toIntOrNull()
        return when (q) {
            1080 -> 6
            720  -> 5
            480  -> 4
            360  -> 3
            240  -> 2
            else -> {
                val br = BITRATE_RE.find(url)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                min(5, when {
                    br >= 8000 -> 5
                    br >= 5000 -> 4
                    br >= 2500 -> 3
                    br >= 1200 -> 2
                    br >= 700  -> 1
                    else       -> 0
                })
            }
        }
    }

    /** Quick HEAD: Content-Length. Skips if called on main thread. */
    private fun headContentLength(url: String): Long {
        try {
            val looper = android.os.Looper.myLooper()
            if (looper != null && looper == android.os.Looper.getMainLooper()) return -1L
        } catch (_: Throwable) {}
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 2000
                readTimeout = 2000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android)")
            }
            conn.connect()
            val len = conn.getHeaderFieldLong("Content-Length", -1L)
            conn.disconnect()
            len
        } catch (_: Throwable) { -1L }
    }

    /** Quick HEAD: Content-Type. Skips if called on main thread. */
    private fun headContentType(url: String): String? {
        try {
            val looper = android.os.Looper.myLooper()
            if (looper != null && looper == android.os.Looper.getMainLooper()) return null
        } catch (_: Throwable) {}
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 2000
                readTimeout = 2000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android)")
            }
            conn.connect()
            val type = conn.contentType
            conn.disconnect()
            type
        } catch (_: Throwable) { null }
    }
}
