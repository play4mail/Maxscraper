package com.example.maxscraper

import android.content.Context
import android.media.MediaMetadataRetriever
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import com.arthenica.ffmpegkit.StatisticsCallback
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

object FfmpegHlsDownloader {

    interface Listener {
        /**
         * @param percent    1..99 while running; caller (service) will force 100 on success
         * @param timeMs     processed media position (ms), 0 if unknown
         * @param totalMs    total duration (ms), 0 if unknown
         * @param bytesSoFar bytes currently written to the output file
         */
        fun onProgress(percent: Int, timeMs: Long, totalMs: Long, bytesSoFar: Long)
        fun onLog(line: String)
        fun onDone(success: Boolean, output: File?, error: String?)
    }

    fun downloadM3u8ToMp4(
        context: Context,
        m3u8Url: String,
        outTitle: String,
        listener: Listener
    ) {
        Thread {
            try {
                val dir = File(context.getExternalFilesDir(null), "Downloads")
                if (!dir.exists()) dir.mkdirs()
                val safe = sanitizeFileName(outTitle).let { if (it.endsWith(".mp4", true)) it else "$it.mp4" }
                val outFile = File(dir, safe)
                if (outFile.exists() && outFile.length() == 0L) outFile.delete()

                val durationMs: Long = probeDurationMs(m3u8Url)
                val pct = AtomicInteger(0)

                val cmd = listOf(
                    "-y",
                    "-i", m3u8Url,
                    "-c", "copy",
                    "-bsf:a", "aac_adtstoasc",
                    outFile.absolutePath
                ).joinToString(" ") { if (it.contains(' ')) "\"$it\"" else it }

                val statsCb = StatisticsCallback { s: Statistics ->
                    // Some builds expose s.time as Double; normalize to Long (ms)
                    val elapsed: Long = try {
                        // Try reflection to Double first, then fall back to .time
                        val t = s.javaClass.getMethod("getTime").invoke(s)
                        when (t) {
                            is Number -> t.toLong()
                            else -> 0L
                        }
                    } catch (_: Throwable) {
                        // If direct access works and is Long
                        runCatching { (s.time as Number).toLong() }.getOrDefault(0L)
                    }.let { max(0L, it) }

                    val total: Long = max(0L, durationMs)
                    val fileBytes: Long = runCatching { outFile.length() }.getOrDefault(0L)

                    val newP: Int = if (total > 0L) {
                        val ratio = elapsed.toDouble() / total.toDouble()
                        val calc = (ratio * 100.0)
                        val asInt = calc.toInt()
                        asInt.coerceIn(1, 99)
                    } else {
                        (pct.get() + 1).coerceAtMost(99)
                    }

                    if (newP > pct.get()) pct.set(newP)
                    listener.onProgress(pct.get(), elapsed, total, fileBytes)
                }

                FFmpegKit.executeAsync(
                    cmd,
                    { ses ->
                        val rc = ses.returnCode
                        if (ReturnCode.isSuccess(rc)) {
                            if (outFile.exists() && outFile.length() > 0L) {
                                listener.onDone(true, outFile, null)
                            } else {
                                listener.onDone(false, null, "Output file missing or zero bytes")
                            }
                        } else {
                            val err = ses.failStackTrace ?: ses.allLogsAsString
                            if (outFile.exists() && outFile.length() == 0L) outFile.delete()
                            listener.onDone(false, null, err)
                        }
                    },
                    { log -> listener.onLog(log.message) },
                    statsCb
                )
            } catch (t: Throwable) {
                listener.onDone(false, null, t.message ?: "unknown error")
            }
        }.start()
    }

    private fun sanitizeFileName(n: String): String =
        n.trim().ifBlank { "video" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")

    private fun probeDurationMs(url: String): Long {
        return try {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(url, mapOf("User-Agent" to "Mozilla/5.0"))
            } catch (_: Throwable) {
                mmr.setDataSource(url)
            }
            val ms = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            mmr.release()
            (ms ?: 0L).coerceAtLeast(0L)
        } catch (_: Throwable) {
            0L
        }
    }
}
