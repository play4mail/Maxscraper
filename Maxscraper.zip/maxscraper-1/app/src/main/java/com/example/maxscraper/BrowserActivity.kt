package com.example.maxscraper

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToLong

@Suppress("SetJavaScriptEnabled")
class BrowserActivity : AppCompatActivity() {

    companion object { const val EXTRA_URL = "com.example.maxscraper.EXTRA_URL" }

    private lateinit var webView: WebView
    private lateinit var toolbar: Toolbar
    private var btnHome: Button? = null
    private var btnList: Button? = null
    private var etUrl: EditText? = null
    private var btnGo: ImageButton? = null
    private var btnRefresh: ImageButton? = null

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(3)

    private val items = java.util.Collections.synchronizedList(mutableListOf<Detected>())
    private var nowPlayingUrl: String? = null
    private var lastGoodUrl: String? = null

    // Badge/pulse state
    private var lastBadgeCount: Int = 0
    private var lastCountKey: String = ""

    // Track eTLD+1-ish to stop programmatic off-site redirects
    private var baseHostSuffix: String? = null
    private fun hostSuffixOf(url: String?): String? {
        if (url.isNullOrBlank()) return null
        return try {
            val host = Uri.parse(url).host ?: return null
            val parts = host.split('.')
            if (parts.size < 2) host else run {
                val last = parts.last()
                val second = parts[parts.size - 2]
                val common = setOf("co","com","org","net","gov","edu","ac")
                if (parts.size >= 3 && second in common && last.length in 2..3) {
                    parts.takeLast(3).joinToString(".")
                } else {
                    parts.takeLast(2).joinToString(".")
                }
            }
        } catch (_: Throwable) { null }
    }

    // Fullscreen video state
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fullScreenContainer: ViewGroup? = null
    private var originalSystemUi = 0
    private var originalOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    data class Detected(
        val url: String,
        val type: Type,
        var meta: Meta? = null
    ) {
        enum class Type { MP4, HLS_MASTER, HLS_MEDIA }
        data class Meta(
            val durationSec: Long? = null,
            val bandwidthBps: Long? = null,
            val resolution: String? = null, // used only for non-master
            val contentLength: Long? = null,
            val isMaster: Boolean = false,
            val variants: List<Variant> = emptyList()
        )
        data class Variant(val url: String, val bandwidthBps: Long?, val resolution: String?, var durationSec: Long?)
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else finish()
        }

        btnHome = findViewById(R.id.btnHome)
        btnList = findViewById(R.id.btnList)
        webView = findViewById(R.id.webView)

        etUrl = findViewById(resources.getIdentifier("etUrl", "id", packageName))
        btnGo = findViewById(resources.getIdentifier("btnGo", "id", packageName))
        btnRefresh = findViewById(resources.getIdentifier("btnRefresh", "id", packageName))

        btnHome?.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()
        }

        // OPEN LIST → MP4/HLS (but MP4s are suppressed if any m3u8 is present)
        btnList?.setOnClickListener {
            val list = buildDownloadableList(waitBriefly = true)
            if (list.isEmpty()) {
                toast("No media found yet — press Play, then tap again.")
                return@setOnClickListener
            }
            val i = Intent(this, M3u8Activity::class.java)
            i.putStringArrayListExtra("EXTRA_M3U8_LIST", ArrayList(list))
            startActivity(i)
        }
        btnList?.setOnLongClickListener {
            synchronized(items) { items.clear() }
            MediaDetector.clear()
            nowPlayingUrl = null
            lastBadgeCount = 0
            lastCountKey = ""
            updateListBadge()
            true
        }

        btnGo?.setOnClickListener {
            val raw = etUrl?.text?.toString()?.trim()
            if (!raw.isNullOrBlank()) {
                baseHostSuffix = hostSuffixOf(raw)
                loadUrlSafe(raw)
            }
        }
        etUrl?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) { btnGo?.performClick(); true } else false
        }
        btnRefresh?.setOnClickListener { webView.reload() }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = WebSettings.getDefaultUserAgent(this@BrowserActivity)
            allowFileAccess = false
            allowContentAccess = true

            // ---- POPUP HARDENING ----
            // Block new windows/popups and stop JS from opening them.
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        CookieManager.getInstance().setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= 21) CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(JSBridge(), "AndroidBridge")

        // ---- Fullscreen & Popup handling ----
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) { callback?.onCustomViewHidden(); return }
                val decor = window.decorView as ViewGroup
                fullScreenContainer = object : ViewGroup(this@BrowserActivity) {
                    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
                        for (i in 0 until childCount) getChildAt(i).layout(0, 0, width, height)
                    }
                }.apply { setBackgroundColor(Color.BLACK) }
                originalSystemUi = decor.systemUiVisibility
                originalOrientation = requestedOrientation
                customView = view
                customViewCallback = callback
                fullScreenContainer?.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                decor.addView(fullScreenContainer, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            }

            override fun onHideCustomView() {
                val decor = window.decorView as ViewGroup
                fullScreenContainer?.let { decor.removeView(it) }
                fullScreenContainer = null
                customView = null
                decor.systemUiVisibility = originalSystemUi
                requestedOrientation = originalOrientation
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
            }

            // HARD BLOCK any attempt to spawn a new window (target=_blank, window.open, ad popups).
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                // Just say no — we keep the user inside this WebView.
                toast("Popup blocked")
                return false
            }

            override fun getDefaultVideoPoster(): Bitmap? = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null) {
                    lastGoodUrl = url
                    etUrl?.setText(url)
                    baseHostSuffix = hostSuffixOf(url)
                    lastBadgeCount = 0
                    lastCountKey = ""
                    updateListBadge()
                }
                MediaDetector.clear()
                injectEarlyHooks()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                // Completely block leaving the app for any non-http(s) scheme.
                if (handleExternalScheme(u)) return true
                val hasGesture = if (Build.VERSION.SDK_INT >= 24) request.hasGesture() else true
                val isMain = if (Build.VERSION.SDK_INT >= 21) request.isForMainFrame else true
                return sameSiteIntercept(u, hasGesture, isMain)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                val u = url ?: return false
                if (handleExternalScheme(u)) return true
                return sameSiteIntercept(u, hasGesture = true, isMainFrame = true)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (!url.isNullOrBlank()) Prefs.setLastBrowserUrl(this@BrowserActivity, url)
                injectLateHooks()
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                request?.url?.toString()?.let {
                    maybeAdd(it)
                    if (isMedia(it) && !shouldIgnore(it)) MediaDetector.report(it)
                }
                return super.shouldInterceptRequest(view, request)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldInterceptRequest(view: WebView?, url: String?): WebResourceResponse? {
                url?.let {
                    maybeAdd(it)
                    if (isMedia(it) && !shouldIgnore(it)) MediaDetector.report(it)
                }
                return super.shouldInterceptRequest(view, url)
            }
        }

        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            val guess = URLUtil.guessFileName(url, contentDisposition, mimeType)
            startDownload(url, guess)
        }

        webView.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                if (customView != null) { (webView.webChromeClient as? WebChromeClient)?.onHideCustomView(); return@setOnKeyListener true }
                if (webView.canGoBack()) { webView.goBack(); return@setOnKeyListener true }
            }
            false
        }

        loadUrlSafe(resolveStartUrl())
    }

    override fun onBackPressed() {
        if (customView != null) { (webView.webChromeClient as? WebChromeClient)?.onHideCustomView(); return }
        if (::webView.isInitialized && webView.canGoBack()) { webView.goBack(); return }
        super.onBackPressed()
    }

    override fun onDestroy() {
        try { webView.stopLoading(); webView.destroy() } catch (_: Throwable) {}
        io.shutdownNow()
        super.onDestroy()
    }

    // -------- External schemes (BLOCK leaving the app) --------
    private fun handleExternalScheme(raw: String): Boolean {
        val url = raw.trim()
        val scheme = kotlin.runCatching { Uri.parse(url).scheme?.lowercase(Locale.US) }.getOrNull() ?: return false
        // Only http(s) stays inside WebView. Everything else is blocked.
        if (scheme == "http" || scheme == "https") return false

        // If it's an intent:// with a http(s) fallback, keep it inside WebView.
        if (scheme == "intent") {
            return try {
                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                val fallback = intent.getStringExtra("browser_fallback_url")
                if (!fallback.isNullOrBlank() && (fallback.startsWith("http://") || fallback.startsWith("https://"))) {
                    ui.post { webView.loadUrl(fallback) }
                } else {
                    toast("Blocked external app")
                }
                true
            } catch (_: Throwable) {
                toast("Blocked external app"); true
            }
        }

        toast("Blocked external app")
        return true
    }

    // -------- Same-site guard --------
    private fun sameSiteIntercept(u: String, hasGesture: Boolean, isMainFrame: Boolean): Boolean {
        if (!isMainFrame) return false
        val dest = hostSuffixOf(u)
        val base = baseHostSuffix ?: hostSuffixOf(webView.url) ?: return false
        if (dest != null && dest.endsWith(base, ignoreCase = true)) return false
        if (hasGesture) { baseHostSuffix = dest; return false }
        toast("Blocked redirect")
        return true
    }

    // -------- Detection helpers --------
    private fun isHttp(u: String): Boolean {
        val low = u.lowercase(Locale.US)
        return low.startsWith("http://") || low.startsWith("https://")
    }

    private fun fileExt(u: String): String {
        val clean = u.substringBefore('#').substringBefore('?')
        val seg = kotlin.runCatching { Uri.parse(clean).lastPathSegment ?: clean }.getOrDefault(clean)
        val dot = seg.lastIndexOf('.')
        return if (dot >= 0) seg.substring(dot + 1).lowercase(Locale.US) else ""
    }

    /** Heuristic acceptance so progressive MP4s without ".mp4" are included. */
    private fun looksLikeMp4(u: String): Boolean {
        val low = u.lowercase(Locale.US)
        if (fileExt(u) == "mp4") return true
        return ("videoplayback" in low) ||
                ("mime=video%2Fmp4" in low) ||
                ("mime=video/mp4" in low) ||
                ("type=video/mp4" in low) ||
                ("format=mp4" in low)
    }

    private fun isMedia(u: String): Boolean {
        val ext = fileExt(u)
        return when {
            ext == "m3u8" -> true
            ext == "mp4" -> true
            looksLikeMp4(u) -> true
            else -> false
        }
    }

    private fun shouldIgnore(u: String): Boolean {
        val url = u.lowercase(Locale.US)
        if (!isHttp(url)) return true
        if (url.startsWith("blob:")) return true
        if (fileExt(url) == "ts") return true
        val patterns = try { Prefs.getIgnoreLinksList(this) } catch (_: Throwable) { emptyList() }
        if (patterns.any { it.isNotEmpty() && url.contains(it) }) return true
        if (url.contains("/ad/") || url.contains("/ads/")) return true
        return false
    }

    private fun promote(u: String): String = u

    private fun maybeAdd(u: String) {
        if (!isMedia(u) || shouldIgnore(u)) return
        val url = promote(u.trim())
        synchronized(items) {
            if (items.any { normalize(it.url) == normalize(url) }) return
            val type = when {
                fileExt(url) == "m3u8" -> Detected.Type.HLS_MEDIA
                else -> Detected.Type.MP4 // treat progressive MP4s (with/without extension) as MP4
            }
            items += Detected(url, type, null)
        }
        MediaDetector.report(url)
        ensureParsed(url)
        updateListBadge()
    }

    private fun ensureParsed(url: String) {
        io.execute {
            when {
                fileExt(url) == "m3u8" -> {
                    val txt = fetchText(url) ?: return@execute
                    val lines = txt.lines()
                    val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF") }
                    if (isMaster) {
                        val variants = parseMaster(lines, url)
                        setMeta(url, Detected.Meta(isMaster = true, variants = variants))
                    } else {
                        val dur = parseDuration(lines)
                        setMeta(url, Detected.Meta(durationSec = dur, isMaster = false))
                    }
                }
                looksLikeMp4(url) || fileExt(url) == "mp4" -> {
                    val metaLen = mp4Head(url)
                    setMeta(url, Detected.Meta(durationSec = null, contentLength = metaLen, isMaster = false))
                }
                else -> { /* ignore */ }
            }
        }
    }

    private fun setMeta(url: String, meta: Detected.Meta) {
        synchronized(items) {
            items.find { normalize(it.url) == normalize(url) }?.meta = meta
        }
        updateListBadge()
    }

    // -------- Build picker list: suppress MP4s if any HLS is present --------
    private fun buildDownloadableList(waitBriefly: Boolean = false): List<String> {
        if (waitBriefly) try { Thread.sleep(150) } catch (_: Throwable) {}

        val candidates = LinkedHashSet<String>().apply {
            addAll(MediaDetector.getCandidates())
            synchronized(items) { items.forEach { add(it.url) } }
        }

        val mp4s = mutableListOf<String>()
        val hls = LinkedHashSet<String>()
        val hlsSortHeights = HashMap<String, Int>() // for sorting

        synchronized(items) {
            items.forEach { det ->
                when {
                    fileExt(det.url) == "m3u8" -> {
                        val m = det.meta
                        if (m?.isMaster == true && !m.variants.isNullOrEmpty()) {
                            // MASTER: include variants; use RESOLUTION or URL heuristic for sort.
                            m.variants.forEach { v ->
                                val h = MediaFilter.heightFromResolution(v.resolution)
                                    ?: heuristicHeightFromUrl(v.url).takeIf { it > 0 }
                                if (h != null && h > 0 && !MediaFilter.isLikelyAd(v.url)) {
                                    hls += v.url
                                    hlsSortHeights[v.url] = h
                                } else if (!MediaFilter.isLikelyAd(v.url)) {
                                    // No resolution — still include but sort lowest.
                                    hls += v.url
                                    hlsSortHeights.putIfAbsent(v.url, 0)
                                }
                            }
                        } else {
                            // MEDIA PLAYLIST: include when VOD or URL hints quality
                            val goodVod = (m?.durationSec ?: 0L) > 0L
                            val h = heuristicHeightFromUrl(det.url)
                            if ((goodVod || h > 0) && !MediaFilter.isLikelyAd(det.url)) {
                                hls += det.url
                                if (h > 0) hlsSortHeights[det.url] = h
                            }
                        }
                    }
                    looksLikeMp4(det.url) || fileExt(det.url) == "mp4" -> mp4s += det.url
                }
            }
        }

        candidates.forEach { u ->
            when {
                fileExt(u) == "m3u8" -> {
                    val h = heuristicHeightFromUrl(u)
                    if (!MediaFilter.isLikelyAd(u)) {
                        hls += u
                        if (h > 0) hlsSortHeights[u] = h
                    }
                }
                looksLikeMp4(u) || fileExt(u) == "mp4" -> mp4s += u
            }
        }

        val hlsSorted = hls.toList().sortedByDescending { hlsSortHeights[it] ?: 0 }

        // **** REQUIREMENT: if any HLS is present, DO NOT include MP4s.
        if (hlsSorted.isNotEmpty()) return hlsSorted

        // Otherwise fall back to MP4s
        val mp4Filtered = MediaFilter.filterMp4(mp4s)
        val out = LinkedHashSet<String>()
        mp4Filtered.forEach { if (!MediaFilter.isLikelyAd(it)) out += it }
        return out.toList()
    }

    /** Fallback when height isn't provided/parsed; look for common tokens in URL. */
    private fun heuristicHeightFromUrl(u: String): Int {
        val low = u.lowercase(Locale.US)
        return when {
            "4320" in low || "8k" in low -> 4320
            "2160" in low || "4k" in low -> 2160
            "1440" in low -> 1440
            "1080" in low -> 1080
            "720"  in low -> 720
            "576"  in low -> 576
            "540"  in low -> 540
            "480"  in low -> 480
            "360"  in low -> 360
            "240"  in low -> 240
            "144"  in low -> 144
            else -> 0
        }
    }

    // -------- UI --------
    private fun updateListBadge() {
        val list = buildDownloadableList(waitBriefly = false)
        val count = list.size
        val key = list.joinToString("|")
        val shouldPulse = (lastBadgeCount == 0 && count > 0) || (count > lastBadgeCount) || (key != lastCountKey)
        ui.post {
            btnList?.text = "List ($count)"
            if (shouldPulse && count > 0) {
                btnList?.let { com.example.maxscraper.ui.FlashPulse.pulse(it) }
            }
            lastBadgeCount = count
            lastCountKey = key
        }
    }

    // -------- JS hooks --------
    private fun injectEarlyHooks() {
        val js = """
          (function(){
            if (window.__MS_EARLY__) return; window.__MS_EARLY__ = true;
            const report = (u)=>{ try{ if(u) AndroidBridge.report(String(u)); }catch(e){} };
            const F = window.fetch;
            window.fetch = function(i, init){ try{ const u=(typeof i==='string')?i:(i&&i.url); if(u) report(u); }catch(e){}; return F.apply(this, arguments); };
            const O = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u){ try{ report(u); }catch(e){}; return O.apply(this, arguments); };
            const W = window.open;
            window.open = function(u,n,s){
              try{
                if (u) report(String(u));
                // Force same-window navigation for popups to stay inside WebView
                if (typeof u === 'string' && /^https?:/i.test(u)) {
                  try { location.href = String(u); return null; } catch(e){}
                }
              }catch(e){}
              try { return W.apply(window, arguments); } catch(e){ return null; }
            };
          })();
        """.trimIndent()
        evaluateJs(js)
    }

    private fun injectLateHooks() {
        val js = """
          (function(){
            if (window.__MS_LATE__) return; window.__MS_LATE__ = true;
            const ping = (v)=>{
              try{
                const u = v.currentSrc || v.src || '';
                if (u && u.startsWith('http')) AndroidBridge.onNowPlaying(String(u));
              }catch(e){}
            };
            const track = (v)=>{
              if (v.__ms_bound) return; v.__ms_bound = true;
              ['loadedmetadata','playing','canplay','durationchange'].forEach(ev=>v.addEventListener(ev, ()=>ping(v), {passive:true}));
              ping(v);
            };
            try{ document.querySelectorAll('video,source').forEach(el=>track(el)); }catch(e){}
            try{
              new MutationObserver(()=>{ try{ document.querySelectorAll('video,source').forEach(el=>track(el)); }catch(e){} })
                .observe(document.documentElement||document.body, {subtree:true, childList:true, attributes:true, attributeFilter:['src']});
            }catch(e){}
          })();
        """.trimIndent()
        evaluateJs(js)
    }

    inner class JSBridge {
        @JavascriptInterface fun report(url: String?) {
            if (url.isNullOrBlank()) return
            maybeAdd(url)
            if (isMedia(url) && !shouldIgnore(url)) MediaDetector.report(promote(url))
        }
        @JavascriptInterface fun onNowPlaying(url: String?) {
            if (url.isNullOrBlank() || !url.startsWith("http")) return
            if (shouldIgnore(url)) return
            val p = promote(url)
            nowPlayingUrl = p
            MediaDetector.report(p)
            MediaDetector.reportPlaying(p)
            ensureParsed(p)
            updateListBadge()
        }
    }

    private fun evaluateJs(code: String, cb: ValueCallback<String>? = null) =
        ui.post { try { webView.evaluateJavascript(code, cb) } catch (_: Throwable) {} }

    // -------- Startup URL resolver --------
    private fun resolveStartUrl(): String {
        intent?.dataString?.takeIf { !it.isNullOrBlank() }?.let { return it }
        intent?.getStringExtra(EXTRA_URL)?.takeIf { !it.isNullOrBlank() }?.let { return it }
        intent?.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { !it.isNullOrBlank() }?.let { return it }
        Prefs.getLastBrowserUrl(this)?.let { return it }
        return Prefs.getBrowserHome(this)
    }

    // -------- Networking --------
    private fun fetchText(url: String): String? = try {
        val c = open(url, "GET")
        c.inputStream.use { BufferedReader(InputStreamReader(it)).readText() }.also { c.disconnect() }
    } catch (_: Throwable) { null }

    private fun mp4Head(url: String): Long? = try {
        val c = open(url, "HEAD")
        val len = c.getHeaderFieldLong("Content-Length", -1L).takeIf { it > 0 }
        c.disconnect(); len
    } catch (_: Throwable) { null }

    private fun open(u: String, method: String): HttpURLConnection {
        val c = (URL(u).openConnection() as HttpURLConnection)
        c.requestMethod = method
        c.instanceFollowRedirects = true
        c.connectTimeout = 15000
        val ref = lastGoodUrl
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", webView.settings.userAgentString)
        CookieManager.getInstance().getCookie(u)?.let { c.setRequestProperty("Cookie", it) }
        if (!ref.isNullOrBlank()) c.setRequestProperty("Referer", ref)
        return c
    }

    // -------- HLS helpers --------
    private fun parseMaster(lines: List<String>, baseUrl: String): List<Detected.Variant> {
        val out = mutableListOf<Detected.Variant>()
        var bw: Long? = null
        var res: String? = null
        lines.forEach { s ->
            val line = s.trim()
            if (line.startsWith("#EXT-X-STREAM-INF", true)) {
                bw = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.getOrNull(1)?.toLongOrNull()
                res = Regex("RESOLUTION=(\\d+x\\d+)").find(line)?.groupValues?.getOrNull(1)
            } else if (line.isNotBlank() && !line.startsWith("#")) {
                val url = resolve(baseUrl, line)
                out += Detected.Variant(url, bw, res, null)
                bw = null; res = null
            }
        }
        out.take(12).forEach { v ->
            val text = fetchText(v.url)
            v.durationSec = text?.let { parseDuration(it.lines()) }
        }
        return out
    }

    private fun parseDuration(lines: List<String>): Long? {
        var total = 0.0; var end = false
        lines.forEach { l ->
            val t = l.trim()
            if (t.startsWith("#EXTINF:")) {
                t.removePrefix("#EXTINF:")
                    .substringBefore(",")
                    .toDoubleOrNull()?.let { total += it }
            }
            if (t.startsWith("#EXT-X-ENDLIST")) end = true
        }
        return if (total > 0 && end) total.roundToLong() else null
    }

    private fun resolve(base: String, rel: String): String =
        try { URL(URL(base), rel).toString() } catch (_: Throwable) { rel }

    // -------- Downloads --------
    private fun startDownload(url: String, guessed: String?) {
        when {
            fileExt(url) == "m3u8" -> {
                toast("This source is streaming (HLS). Use Convert to MP4 in Active/Completed.")
            }
            looksLikeMp4(url) || fileExt(url) == "mp4" -> {
                val name = ensureMp4Name(guessNameFromUrl(url, guessed))
                DownloadRepository.startDownload(this, url, name, lastGoodUrl)
                toast("Downloading: $name")
            }
            else -> toast("Unsupported media")
        }
    }

    // -------- Small utils --------
    private fun loadUrlSafe(raw: String) {
        val url = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) raw else "https://$raw"
        lastGoodUrl = url
        try { webView.loadUrl(url) } catch (_: Throwable) { toast("Invalid URL") }
    }

    private fun guessNameFromUrl(url: String, fallback: String? = null): String {
        val last = kotlin.runCatching { Uri.parse(url).lastPathSegment ?: "" }.getOrDefault("")
        val base = when {
            !fallback.isNullOrBlank() -> fallback
            last.isNotBlank() -> last
            else -> "video.mp4"
        }
        return base.substringAfterLast('/').substringBefore('?').substringBefore('#')
    }
    private fun ensureMp4Name(n: String) = if (n.lowercase(Locale.US).endsWith(".mp4")) n else "$n.mp4"
    private fun toast(msg: String) = ui.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    private fun normalize(u: String?) = u?.let { Uri.parse(it).buildUpon().fragment(null).build().toString() } ?: ""
}
