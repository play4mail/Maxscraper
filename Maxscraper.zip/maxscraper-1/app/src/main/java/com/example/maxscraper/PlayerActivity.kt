package com.example.maxscraper

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class PlayerActivity : AppCompatActivity() {

    companion object { const val EXTRA_TITLE = "extra_title" }

    private lateinit var video: VideoView
    private var mediaVol = 1f
    private var muted = false
    private var brightness: Float = -1f
    private var isFullscreen = false

    private val ui = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null
    private lateinit var seek: SeekBar
    private lateinit var curTime: TextView
    private lateinit var totalTime: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        video = VideoView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setOnPreparedListener { mp ->
                mp.isLooping = false
                mp.setVolume(if (muted) 0f else mediaVol, if (muted) 0f else mediaVol)
                start()
                // init seek info
                totalTime.text = formatTime(duration / 1000)
                seek.max = duration
                startTicker()
            }
            setOnCompletionListener {
                stopTicker()
                seek.progress = duration
                curTime.text = formatTime((duration / 1000))
            }
        }
        root.addView(video)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x66000000)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
            setPadding(16, 8, 16, 16)
        }

        // Controls row 1: seekbar + time
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setPadding(0, 4, 0, 8)
        }

        curTime = TextView(this).apply { setTextColor(Color.WHITE); text = "0:00" }
        totalTime = TextView(this).apply { setTextColor(Color.WHITE); text = "--:--" }
        seek = SeekBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                var userSeeking = false
                override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    userSeeking = false
                    runCatching { video.seekTo(progress) }
                }
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        curTime.text = formatTime((p / 1000))
                    }
                }
            })
        }
        row1.addView(curTime)
        row1.addView(seek)
        row1.addView(totalTime)

        // Controls row 2: fullscreen / mute / volume / brightness
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        fun makeBtn(txt: String, onClick: (Button) -> Unit): Button =
            Button(this).apply {
                text = txt
                setAllCaps(false)
                setOnClickListener { onClick(this) }
            }

        val btnFullscreen = makeBtn("Fullscreen") { btn ->
            isFullscreen = !isFullscreen
            applyFullscreen(isFullscreen)
            btn.text = if (isFullscreen) "Exit Fullscreen" else "Fullscreen"
        }

        val btnMute = makeBtn("Mute") { btn ->
            muted = !muted
            val vol = if (muted) 0f else mediaVol
            runCatching { internalMediaPlayer()?.setVolume(vol, vol) }
            btn.text = if (muted) "Unmute" else "Mute"
        }

        val volSeek = SeekBar(this).apply {
            max = 100; progress = (mediaVol * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    mediaVol = (p / 100f).coerceIn(0f, 1f)
                    if (!muted) runCatching { internalMediaPlayer()?.setVolume(mediaVol, mediaVol) }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        val brightSeek = SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    brightness = (p / 100f).coerceIn(0.01f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = brightness
                    window.attributes = lp
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        val weight = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        row2.addView(btnFullscreen)
        row2.addView(btnMute)
        row2.addView(TextView(this).apply { setTextColor(Color.WHITE); text = "Vol" })
        row2.addView(volSeek, weight)
        row2.addView(TextView(this).apply { setTextColor(Color.WHITE); text = "Bright" })
        row2.addView(brightSeek, weight)

        bar.addView(row1)
        bar.addView(row2)

        root.addView(bar)
        setContentView(root)

        val uri = intent?.data ?: run {
            Toast.makeText(this, "No video", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        video.setVideoURI(uri)
    }

    private fun startTicker() {
        stopTicker()
        ticker = object : Runnable {
            override fun run() {
                if (video.isPlaying) {
                    val pos = video.currentPosition
                    seek.progress = pos
                    curTime.text = formatTime((pos / 1000))
                }
                ui.postDelayed(this, 500)
            }
        }
        ui.post(ticker!!)
    }

    private fun stopTicker() {
        ticker?.let { ui.removeCallbacks(it) }
        ticker = null
    }

    private fun applyFullscreen(enable: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (enable) {
            controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            controller.show(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
        }
    }

    private fun formatTime(sec: Int): String {
        val s = sec % 60
        val m = (sec / 60) % 60
        val h = sec / 3600
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    @Suppress("DiscouragedPrivateApi")
    private fun internalMediaPlayer(): android.media.MediaPlayer? =
        try {
            val f = VideoView::class.java.getDeclaredField("mMediaPlayer")
            f.isAccessible = true
            f.get(video) as? android.media.MediaPlayer
        } catch (_: Throwable) { null }

    override fun onDestroy() {
        stopTicker()
        runCatching { video.stopPlayback() }
        super.onDestroy()
    }
}
